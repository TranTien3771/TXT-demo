#include <bits/stdc++.h>
#define int long long
#define fi first
#define se second
#define lb lower_bound
#define ub upper_bound
#define pii pair<int, int>
#define pb push_back
const int maxn = 1e6 + 5;
const int mod = 1e9 + 7;
const int inf = 1e18;

using namespace std;

int a[maxn];


main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    if (fopen("PACKAGES.INP", "r")){
        freopen("PACKAGES.INP", "r", stdin);
        freopen("PACKAGES.OUT", "w", stdout);
    }

    int t; cin >> t;
    while (t--){
        priority_queue<int> pq1, pq2;
        int n, q, cnt = 1; cin >> n >> q;
        for (int i = 1; i <= n; i++) cin >> a[i];
        pq1.push(a[1]);
        // cout << cnt << " ";
        for (int i = 2; i <= n; i++){
            while (!pq1.empty() && pq1.top() + a[i] > q){
                pq2.push(pq1.top());
                pq1.pop();
            }   
            // cout << pq1.size() << " ";
            if (pq1.empty()) cnt++, pq1.push(a[i]);
            else {
                int top = pq1.top();
                pq1.pop();
                top += a[i];
                pq1.push(top);
            }
            while (!pq2.empty()){
                pq1.push(pq2.top());
                pq2.pop();
            }
            // cout << cnt << ' ';
        }
        cout << cnt << '\n';
    }

    return 0;
}

//TranTien